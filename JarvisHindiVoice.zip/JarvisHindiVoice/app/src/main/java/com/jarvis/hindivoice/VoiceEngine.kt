package com.jarvis.hindivoice

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger

data class VoiceParams(
    val rate: Float,
    val pitch: Float,
    val volume: Float,
    val hiVoice: String?,
    val enVoice: String?,
    val expressive: Boolean,
    /** Full https URL of the user's own TTS proxy endpoint, or null for offline voice only. */
    val cloudUrl: String? = null
)

/**
 * Free, offline voice using Android's built-in TextToSpeech.
 * "Expressiveness" is created by splitting text into sentences and giving each one
 * its own pitch/speed plus a short silent pause. It is NOT a clone of any person.
 */
class VoiceEngine(
    context: Context,
    private val usage: Int = AudioAttributes.USAGE_MEDIA,
    onReady: (Boolean) -> Unit
) {
    interface Listener {
        fun onSpeakStart()
        fun onSpeakEnd()
    }

    var listener: Listener? = null
    var ready = false
        private set

    private val appCtx = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var voiceCache: List<Voice> = emptyList()
    private var player: MediaPlayer? = null

    @Volatile private var gen = 0
    @Volatile private var started = false
    private val pending = AtomicInteger(0)

    private data class Seg(
        val text: String, val hindi: Boolean,
        val pitchMul: Float, val rateMul: Float, val pauseMs: Long
    )

    private val progress = object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) {
            if (parseGen(utteranceId) == gen && !started) {
                started = true
                main.post { listener?.onSpeakStart() }
            }
        }
        override fun onDone(utteranceId: String?) = finishSeg(utteranceId)
        @Deprecated("Deprecated in Java")
        override fun onError(utteranceId: String?) = finishSeg(utteranceId)
        override fun onError(utteranceId: String?, errorCode: Int) = finishSeg(utteranceId)
        override fun onStop(utteranceId: String?, interrupted: Boolean) = finishSeg(utteranceId)
    }

    init {
        tts = TextToSpeech(appCtx) { status ->
            ready = status == TextToSpeech.SUCCESS
            if (ready) {
                tts?.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(usage)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                tts?.setOnUtteranceProgressListener(progress)
                voiceCache = try { tts?.voices?.toList() ?: emptyList() } catch (e: Exception) { emptyList() }
            }
            onReady(ready)
        }
    }

    fun voices(): List<Voice> = voiceCache.sortedBy { it.name }

    fun hindiAvailable(): Boolean {
        val r = tts?.isLanguageAvailable(Locale("hi", "IN")) ?: return false
        return r >= TextToSpeech.LANG_AVAILABLE
    }

    fun speak(text: String, p: VoiceParams) {
        stop()
        val url = p.cloudUrl
        if (url != null && url.startsWith("https://")) {
            speakCloud(text, url, p) { speakLocal(text, p) }
        } else {
            speakLocal(text, p)
        }
    }

    fun stop() {
        gen++
        tts?.stop()
        player?.let {
            try { it.stop() } catch (_: Exception) {}
            it.release()
        }
        player = null
        if (started) {
            started = false
            main.post { listener?.onSpeakEnd() }
        }
    }

    fun shutdown() {
        stop()
        tts?.shutdown()
        tts = null
    }

    // ---------- offline path ----------

    private fun speakLocal(text: String, p: VoiceParams) {
        val engine = tts ?: return
        if (!ready) return
        val segs = buildSegments(text, p.expressive)
        if (segs.isEmpty()) return
        val g = gen
        pending.set(segs.size)
        started = false
        segs.forEachIndexed { i, s ->
            selectVoice(engine, s.hindi, p)
            engine.setPitch((p.pitch * s.pitchMul).coerceIn(0.5f, 2f))
            engine.setSpeechRate((p.rate * s.rateMul).coerceIn(0.5f, 2f))
            val params = Bundle().apply {
                putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, p.volume.coerceIn(0f, 1f))
            }
            engine.speak(
                s.text,
                if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD,
                params, "seg_${g}_$i"
            )
            if (p.expressive && s.pauseMs > 0 && i < segs.lastIndex) {
                engine.playSilentUtterance(s.pauseMs, TextToSpeech.QUEUE_ADD, "sil_${g}_$i")
            }
        }
    }

    private fun buildSegments(text: String, expressive: Boolean): List<Seg> =
        text.trim().split(Regex("(?<=[।.!?])\\s+")).filter { it.isNotBlank() }.map { s ->
            val hindi = s.any { it in '\u0900'..'\u097F' }
            val t = s.trimEnd()
            when {
                !expressive -> Seg(s, hindi, 1f, 1f, 150)
                t.endsWith("!") -> Seg(s, hindi, 1.12f, 1.08f, 260)   // excited
                t.endsWith("?") -> Seg(s, hindi, 1.18f, 0.97f, 320)   // curious
                else -> Seg(s, hindi, 1f, 1f, 380)                    // calm, with a beat after
            }
        }

    private fun selectVoice(e: TextToSpeech, hindi: Boolean, p: VoiceParams) {
        val name = if (hindi) p.hiVoice else p.enVoice
        val v = name?.let { n -> voiceCache.firstOrNull { it.name == n } }
        if (v != null) e.voice = v
        else e.language = if (hindi) Locale("hi", "IN") else Locale("en", "IN")
    }

    private fun parseGen(id: String?): Int =
        id?.takeIf { it.startsWith("seg_") }?.split("_")?.getOrNull(1)?.toIntOrNull() ?: -1

    private fun finishSeg(id: String?) {
        if (parseGen(id) != gen) return
        if (pending.decrementAndGet() <= 0) {
            main.post {
                started = false
                listener?.onSpeakEnd()
            }
        }
    }

    // ---------- optional cloud path (user's own proxy; no keys in the app) ----------

    private fun speakCloud(text: String, url: String, p: VoiceParams, fallback: () -> Unit) {
        val myGen = gen
        val lang = if (text.any { it in '\u0900'..'\u097F' }) "hi" else "en"
        Thread {
            try {
                val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    doOutput = true
                    connectTimeout = 8000
                    readTimeout = 20000
                    setRequestProperty("Content-Type", "application/json")
                }
                val body = JSONObject().put("text", text).put("lang", lang).toString()
                conn.outputStream.use { it.write(body.toByteArray()) }
                if (conn.responseCode !in 200..299) throw IOException("HTTP ${conn.responseCode}")
                val f = File(appCtx.cacheDir, "cloud_voice.mp3")
                conn.inputStream.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                conn.disconnect()
                main.post { if (myGen == gen) playFile(f, p.volume) }
            } catch (e: Exception) {
                main.post { if (myGen == gen) fallback() }
            }
        }.start()
    }

    private fun playFile(f: File, volume: Float) {
        val mp = MediaPlayer()
        player = mp
        try {
            mp.setAudioAttributes(
                AudioAttributes.Builder().setUsage(usage)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
            )
            mp.setDataSource(f.path)
            mp.setOnPreparedListener {
                it.setVolume(volume, volume)
                it.start()
                started = true
                listener?.onSpeakStart()
            }
            mp.setOnCompletionListener { endPlayer(mp) }
            mp.setOnErrorListener { _, _, _ -> endPlayer(mp); true }
            mp.prepareAsync()
        } catch (e: Exception) {
            endPlayer(mp)
        }
    }

    private fun endPlayer(mp: MediaPlayer) {
        try { mp.release() } catch (_: Exception) {}
        if (player === mp) player = null
        started = false
        listener?.onSpeakEnd()
    }
}
