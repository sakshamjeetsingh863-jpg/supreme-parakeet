package com.jarvis.hindivoice

import kotlin.random.Random

/** Original playful interjections. It adds a comedic *vibe*; it does not imitate any real character. */
object Persona {
    private val hiOpen = listOf("अरे वाह!", "ओहो!", "सुनो सुनो!", "अरे भाई!")
    private val hiClose = listOf("हा हा हा!", "मज़ा आ गया!", "है ना मज़ेदार?")
    private val enOpen = listOf("Oh wow!", "Hey hey!", "Listen up!")
    private val enClose = listOf("Ha ha ha!", "Pretty fun, right?")

    fun flavor(text: String): String {
        if (text.length > 220) return text
        val hindi = text.any { it in '\u0900'..'\u097F' }
        val open = (if (hindi) hiOpen else enOpen).random()
        val close = (if (hindi) hiClose else enClose).random()
        return when (Random.nextInt(3)) {
            0 -> "$open $text"
            1 -> "$text $close"
            else -> "$open $text $close"
        }
    }
}
