package com.jarvis.hindivoice

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class WakeUpReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (!SettingsStore(context).wakeEnabled) return
        AlarmScheduler.schedule(context) // set up tomorrow's 7:00 AM IST
        try {
            ContextCompat.startForegroundService(context, Intent(context, WakeUpService::class.java))
        } catch (e: Exception) {
            WakeUpService.postFallbackNotification(context) // OS refused background start
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (SettingsStore(context).wakeEnabled) AlarmScheduler.schedule(context)
    }
}
