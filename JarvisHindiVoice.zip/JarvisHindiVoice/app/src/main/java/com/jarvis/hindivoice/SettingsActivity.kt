package com.jarvis.hindivoice

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.slider.Slider
import com.google.android.material.switchmaterial.SwitchMaterial
import kotlin.math.round

class SettingsActivity : AppCompatActivity() {
    private lateinit var store: SettingsStore
    private lateinit var voice: VoiceEngine
    private lateinit var rate: Slider
    private lateinit var pitch: Slider
    private lateinit var volume: Slider
    private lateinit var spinHi: Spinner
    private lateinit var spinEn: Spinner
    private lateinit var swExpressive: SwitchMaterial
    private lateinit var swEnglish: SwitchMaterial
    private lateinit var swWake: SwitchMaterial
    private lateinit var swCloud: SwitchMaterial
    private lateinit var etProxy: EditText
    private var hiVoices: List<Voice> = emptyList()
    private var enVoices: List<Voice> = emptyList()

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        store = SettingsStore(this)

        rate = findViewById(R.id.sliderRate)
        pitch = findViewById(R.id.sliderPitch)
        volume = findViewById(R.id.sliderVolume)
        spinHi = findViewById(R.id.spinHi)
        spinEn = findViewById(R.id.spinEn)
        swExpressive = findViewById(R.id.swExpressive)
        swEnglish = findViewById(R.id.swEnglishListen)
        swWake = findViewById(R.id.swWake)
        swCloud = findViewById(R.id.swCloud)
        etProxy = findViewById(R.id.etProxy)

        loadFromStore()
        bindLabel(rate, R.id.labelRate, "Speed")
        bindLabel(pitch, R.id.labelPitch, "Pitch")
        bindLabel(volume, R.id.labelVolume, "Volume")

        findViewById<TextView>(R.id.tvInfo).text = INFO

        voice = VoiceEngine(this) { ok ->
            if (ok) populateVoices()
            else Toast.makeText(this, "No text-to-speech engine found", Toast.LENGTH_LONG).show()
        }

        findViewById<MaterialButton>(R.id.btnTest).setOnClickListener {
            // Speaks with the CURRENT (unsaved) slider values.
            voice.speak(TEST_TEXT, draft())
        }
        findViewById<MaterialButton>(R.id.btnPreset).setOnClickListener {
            rate.value = 1.15f; pitch.value = 1.35f; volume.value = 1f
            swExpressive.isChecked = true
        }
        findViewById<MaterialButton>(R.id.btnSave).setOnClickListener { save() }
        findViewById<MaterialButton>(R.id.btnInstallVoice).setOnClickListener {
            try { startActivity(Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA)) }
            catch (e: Exception) {
                try { startActivity(Intent("com.android.settings.TTS_SETTINGS")) }
                catch (e2: Exception) { Toast.makeText(this, "Open Android Settings > Text-to-speech", Toast.LENGTH_LONG).show() }
            }
        }
        findViewById<MaterialButton>(R.id.btnExactAlarm).setOnClickListener {
            if (Build.VERSION.SDK_INT >= 31) {
                startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
            } else Toast.makeText(this, "Not needed on this Android version", Toast.LENGTH_SHORT).show()
        }
        findViewById<MaterialButton>(R.id.btnBattery).setOnClickListener {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
        swWake.setOnCheckedChangeListener { _, on ->
            if (on && Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun loadFromStore() {
        rate.value = store.rate.coerceIn(0.5f, 2f)
        pitch.value = store.pitch.coerceIn(0.5f, 2f)
        volume.value = store.volume.coerceIn(0f, 1f)
        swExpressive.isChecked = store.expressive
        swEnglish.isChecked = store.listenEnglish
        swWake.isChecked = store.wakeEnabled
        swCloud.isChecked = store.cloudEnabled
        etProxy.setText(store.proxyBase)
    }

    private fun bindLabel(s: Slider, labelId: Int, name: String) {
        val tv = findViewById<TextView>(labelId)
        tv.text = "$name: %.2f".format(s.value)
        s.addOnChangeListener { _, v, _ -> tv.text = "$name: %.2f".format(v) }
    }

    private fun populateVoices() {
        val all = voice.voices()
        hiVoices = all.filter { it.locale.language == "hi" }
        enVoices = all.filter { it.locale.language == "en" }
        fill(spinHi, hiVoices, store.hiVoice)
        fill(spinEn, enVoices, store.enVoice)
        if (hiVoices.isEmpty())
            Toast.makeText(this, "No Hindi voice installed. Tap 'Install / manage voice data'.", Toast.LENGTH_LONG).show()
    }

    private fun fill(sp: Spinner, list: List<Voice>, selected: String?) {
        val names = listOf("System default") + list.map {
            "${it.name}  (${it.locale.displayName})" + if (it.isNetworkConnectionRequired) " [online]" else " [offline]"
        }
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        val idx = list.indexOfFirst { it.name == selected }
        sp.setSelection(if (idx >= 0) idx + 1 else 0)
    }

    private fun selectedName(sp: Spinner, list: List<Voice>): String? =
        (sp.selectedItemPosition - 1).let { if (it >= 0 && it < list.size) list[it].name else null }

    private fun r2(v: Float) = round(v * 100f) / 100f

    private fun draft() = VoiceParams(
        r2(rate.value), r2(pitch.value), r2(volume.value),
        selectedName(spinHi, hiVoices), selectedName(spinEn, enVoices),
        swExpressive.isChecked,
        etProxy.text.toString().trim().trimEnd('/').let {
            if (swCloud.isChecked && it.startsWith("https://")) "$it/tts" else null
        }
    )

    private fun save() {
        store.rate = r2(rate.value)
        store.pitch = r2(pitch.value)
        store.volume = r2(volume.value)
        store.hiVoice = selectedName(spinHi, hiVoices)
        store.enVoice = selectedName(spinEn, enVoices)
        store.expressive = swExpressive.isChecked
        store.listenEnglish = swEnglish.isChecked
        store.proxyBase = etProxy.text.toString().trim()
        store.cloudEnabled = swCloud.isChecked
        store.wakeEnabled = swWake.isChecked

        if (store.wakeEnabled) {
            val exact = AlarmScheduler.schedule(this)
            if (!exact) Toast.makeText(
                this, "Saved, but exact alarms are not allowed. Tap 'Allow exact alarms' or the wake-up may be late.",
                Toast.LENGTH_LONG
            ).show() else Toast.makeText(this, "Saved. Wake-up set for 7:00 AM IST.", Toast.LENGTH_SHORT).show()
        } else {
            AlarmScheduler.cancel(this)
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        }
        finish()
    }

    override fun onDestroy() {
        voice.shutdown()
        super.onDestroy()
    }

    companion object {
        const val TEST_TEXT =
            "अरे वाह! ये मेरी नई आवाज़ है। कैसी लग रही है? Hello, and this is my English voice!"
        const val INFO = """Permissions
• Microphone: only used while you tap the mic, for voice input.
• Notifications: needed (Android 13+) so the 7:00 AM wake-up can show its notification.
• Exact alarms: lets the wake-up fire at exactly 7:00 AM IST. Without it Android may delay it.
• Internet: used ONLY if you enter your own proxy URL. The offline voice never needs it.

Background limits
• Some phone makers (Xiaomi, Oppo, Vivo, Samsung, etc.) kill background apps. If the 7:00 AM message does not play, disable battery optimization for this app and allow autostart.
• Force-stopping the app cancels its alarms until you open it again.
• Android 14/15 can restrict starting audio services from the background; if blocked you get a notification instead.

Voice notes
• The offline voice is Android's free system voice, tuned (speed, pitch, pauses) to sound playful. It is not a copy of any real person or character.
• Waveform animation reflects speaking state; Android does not expose live TTS audio levels.
• Hindi voice data may need a one-time download (Google Speech Services)."""
    }
}
