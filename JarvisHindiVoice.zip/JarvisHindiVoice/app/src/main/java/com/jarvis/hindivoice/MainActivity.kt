package com.jarvis.hindivoice

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton

class MainActivity : AppCompatActivity() {
    private lateinit var store: SettingsStore
    private lateinit var voice: VoiceEngine
    private lateinit var wave: WaveformView
    private lateinit var status: TextView
    private lateinit var reply: TextView
    private var recognizer: SpeechRecognizer? = null

    private val micPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startListening()
            else status.text = "Microphone permission denied. Voice input is off; you can still use Settings > Test."
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        store = SettingsStore(this)
        wave = findViewById(R.id.wave)
        status = findViewById(R.id.status)
        reply = findViewById(R.id.reply)

        voice = VoiceEngine(this) { ok ->
            if (!ok) status.text = "Text-to-speech engine unavailable on this device."
            else if (!voice.hindiAvailable())
                status.text = "Hindi voice data missing. Open Settings > Install / manage voice data."
        }
        voice.listener = object : VoiceEngine.Listener {
            override fun onSpeakStart() { wave.setActive(true); status.text = "Speaking…" }
            override fun onSpeakEnd() { wave.setActive(false); status.text = "Ready" }
        }

        findViewById<MaterialButton>(R.id.mic).setOnClickListener { onMicTapped() }
        findViewById<MaterialButton>(R.id.settingsBtn).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    private fun onMicTapped() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            == PackageManager.PERMISSION_GRANTED
        ) startListening()
        else micPermission.launch(Manifest.permission.RECORD_AUDIO)
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "No speech recognition service found. Install or enable Google app / Speech Services."
            return
        }
        voice.stop()
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { r ->
            r.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { wave.setActive(true); status.text = "Listening…" }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { wave.setActive(false); status.text = "Thinking…" }
                override fun onError(error: Int) {
                    wave.setActive(false)
                    status.text = "Didn't catch that (error $error). Tap and try again."
                }
                override fun onResults(results: Bundle?) {
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (text.isNullOrBlank()) status.text = "Didn't catch that." else handleQuery(text)
                }
                override fun onPartialResults(partialResults: Bundle?) {
                    partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()?.let { reply.text = "You: $it…" }
                }
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (store.listenEnglish) "en-IN" else "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            })
        }
    }

    private fun handleQuery(text: String) {
        reply.text = "You: $text"
        status.text = "Thinking…"
        val base = store.proxyBase
        Thread {
            val answer = (if (base.isNotBlank()) Brain.remote(base, text) else null) ?: Brain.localReply(text)
            runOnUiThread { say(answer) }
        }.start()
    }

    private fun say(text: String) {
        val finalText = if (store.expressive) Persona.flavor(text) else text
        reply.text = finalText
        voice.speak(finalText, store.toParams())
    }

    override fun onDestroy() {
        recognizer?.destroy()
        voice.shutdown()
        super.onDestroy()
    }
}
