package com.jarvis.hindivoice

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

class WakeUpService : Service() {
    private var voice: VoiceEngine? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val n = buildNotification(this)
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(1, n)
        }
        val store = SettingsStore(this)
        Handler(Looper.getMainLooper()).postDelayed({ stopSelf() }, 60_000) // safety net

        voice = VoiceEngine(this, AudioAttributes.USAGE_ALARM) { ok ->
            if (!ok) { stopSelf(); return@VoiceEngine }
            voice?.listener = object : VoiceEngine.Listener {
                override fun onSpeakStart() {}
                override fun onSpeakEnd() { stopSelf() }
            }
            voice?.speak(WAKE_TEXT, store.toParams())
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        voice?.shutdown()
        super.onDestroy()
    }

    companion object {
        const val CHANNEL = "jarvis_wake"
        const val WAKE_TEXT =
            "सुप्रभात! अरे उठो उठो, सुबह के सात बज गए हैं! आज का दिन धमाल होने वाला है। चलो, शुरू करते हैं!"

        private fun ensureChannel(ctx: Context) {
            if (Build.VERSION.SDK_INT >= 26) {
                val nm = ctx.getSystemService(NotificationManager::class.java)
                nm.createNotificationChannel(
                    NotificationChannel(CHANNEL, "JARVIS wake-up", NotificationManager.IMPORTANCE_HIGH)
                )
            }
        }

        fun buildNotification(ctx: Context): Notification {
            ensureChannel(ctx)
            val open = PendingIntent.getActivity(
                ctx, 0, Intent(ctx, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            return NotificationCompat.Builder(ctx, CHANNEL)
                .setSmallIcon(R.drawable.ic_jarvis)
                .setContentTitle("JARVIS")
                .setContentText("सुप्रभात! ☀️")
                .setContentIntent(open)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .build()
        }

        fun postFallbackNotification(ctx: Context) {
            try { NotificationManagerCompat.from(ctx).notify(2, buildNotification(ctx)) } catch (_: Exception) {}
        }
    }
}
