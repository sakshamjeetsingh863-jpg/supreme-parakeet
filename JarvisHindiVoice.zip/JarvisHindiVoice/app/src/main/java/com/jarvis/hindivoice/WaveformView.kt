package com.jarvis.hindivoice

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import kotlin.math.abs
import kotlin.math.sin
import kotlin.random.Random

/**
 * Animated blue voice waveform. Android's TextToSpeech does not expose live audio samples,
 * so the animation is driven by the speaking/listening state, not the real audio amplitude.
 */
class WaveformView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    private val bars = 32
    private val levels = FloatArray(bars) { 0.05f }
    private var active = false
    private var t = 0f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF00E5FF.toInt()
        strokeCap = Paint.Cap.ROUND
    }

    fun setActive(a: Boolean) {
        active = a
        postInvalidateOnAnimation()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        val step = w / bars
        paint.strokeWidth = step * 0.5f
        t += 0.18f
        var moving = active
        for (i in 0 until bars) {
            val target = if (active)
                0.25f + 0.75f * abs(sin(t + i * 0.45f)) * (0.5f + 0.5f * Random.nextFloat())
            else 0.05f
            levels[i] += (target - levels[i]) * 0.25f
            if (levels[i] > 0.06f) moving = true
            val bh = levels[i] * h
            val x = step * i + step / 2
            canvas.drawLine(x, h / 2 - bh / 2, x, h / 2 + bh / 2, paint)
        }
        if (moving) postInvalidateOnAnimation()
    }
}
