package com.jarvis.hindivoice

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.Locale

/** Offline rule-based replies (always works) + optional call to the user's own https proxy. */
object Brain {
    private val ist = ZoneId.of("Asia/Kolkata")
    private val hiDays = listOf("सोमवार", "मंगलवार", "बुधवार", "गुरुवार", "शुक्रवार", "शनिवार", "रविवार")
    private val hiMonths = listOf(
        "जनवरी", "फ़रवरी", "मार्च", "अप्रैल", "मई", "जून",
        "जुलाई", "अगस्त", "सितंबर", "अक्टूबर", "नवंबर", "दिसंबर"
    )
    private val hiJokes = listOf(
        "टीचर ने पूछा, सबसे तेज़ चीज़ क्या है? गोलू बोला, छुट्टी की घंटी, मैडम!",
        "मोबाइल ने चार्जर से कहा, तुम्हारे बिना मैं ज़ीरो हूँ। चार्जर बोला, और मेरे बिना तुम सीधे हीरो से ज़ीरो!",
        "पप्पू ने घड़ी देखी और बोला, अरे! वक़्त तो चल रहा है, मैं ही रुका हुआ हूँ!"
    )
    private val enJokes = listOf(
        "Why did the phone wear glasses? Because it lost all its contacts!",
        "I told my battery a joke. It said, that drained me!"
    )

    fun localReply(raw: String): String {
        val q = raw.lowercase(Locale.ROOT)
        val hindi = raw.any { it in '\u0900'..'\u097F' }
        fun has(vararg k: String) = k.any { q.contains(it) }
        val now = ZonedDateTime.now(ist)

        return when {
            has("नमस्ते", "हेलो", "हैलो", "hello", "hey jarvis") ->
                if (hindi) "नमस्ते! मैं जार्विस हूँ। बोलिए, क्या हुक्म है?" else "Hello! I'm JARVIS. How can I help?"
            has("समय", "टाइम", "कितने बजे", "time") -> {
                val h12 = if (now.hour % 12 == 0) 12 else now.hour % 12
                if (hindi) "अभी $h12 बजकर ${now.minute} मिनट हुए हैं!"
                else "It's $h12:${now.minute.toString().padStart(2, '0')} ${if (now.hour < 12) "AM" else "PM"} in India."
            }
            has("तारीख", "तारिख", "आज कौन सा दिन", "date", "what day") ->
                if (hindi) "आज ${hiDays[now.dayOfWeek.value - 1]} है, ${now.dayOfMonth} ${hiMonths[now.monthValue - 1]} ${now.year}।"
                else "Today is ${now.dayOfWeek.name.lowercase().replaceFirstChar { it.uppercase() }}, ${now.dayOfMonth}/${now.monthValue}/${now.year}."
            has("जोक", "चुटकुला", "मज़ाक", "मजाक", "joke", "funny") ->
                if (hindi) hiJokes.random() else enJokes.random()
            has("तुम कौन", "आप कौन", "तुम्हारा नाम", "who are you", "your name") ->
                if (hindi) "मैं जार्विस हूँ, आपका हँसमुख असिस्टेंट!" else "I'm JARVIS, your cheerful assistant!"
            has("शुक्रिया", "धन्यवाद", "thanks", "thank you") ->
                if (hindi) "अरे कोई बात नहीं! ये तो मेरा काम है!" else "Anytime! That's what I'm here for!"
            else ->
                if (hindi) "हम्म, ये मुझे अभी समझ नहीं आया। समय, तारीख या जोक पूछकर देखिए!"
                else "Hmm, I didn't get that yet. Try asking for the time, the date, or a joke!"
        }
    }

    /** Optional: POST {"message": "..."} to https://YOUR-PROXY/chat -> {"reply": "..."} (blocking; call off the main thread). */
    fun remote(base: String, message: String): String? {
        if (!base.startsWith("https://")) return null
        return try {
            val conn = (URL(base.trimEnd('/') + "/chat").openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                connectTimeout = 8000
                readTimeout = 25000
                setRequestProperty("Content-Type", "application/json")
            }
            conn.outputStream.use { it.write(JSONObject().put("message", message).toString().toByteArray()) }
            if (conn.responseCode !in 200..299) return null
            val reply = JSONObject(conn.inputStream.bufferedReader().readText()).optString("reply")
            conn.disconnect()
            reply.ifBlank { null }
        } catch (e: Exception) {
            null
        }
    }
}
