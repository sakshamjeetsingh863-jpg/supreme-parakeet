package com.jarvis.hindivoice

import android.content.Context

/** Plain local storage. NO API keys are ever stored here. */
class SettingsStore(context: Context) {
    private val p = context.applicationContext
        .getSharedPreferences("jarvis_settings", Context.MODE_PRIVATE)

    var rate: Float
        get() = p.getFloat("rate", 1.1f)
        set(v) = p.edit().putFloat("rate", v).apply()

    var pitch: Float
        get() = p.getFloat("pitch", 1.25f)
        set(v) = p.edit().putFloat("pitch", v).apply()

    var volume: Float
        get() = p.getFloat("volume", 1.0f)
        set(v) = p.edit().putFloat("volume", v).apply()

    var hiVoice: String?
        get() = p.getString("hiVoice", null)
        set(v) = p.edit().putString("hiVoice", v).apply()

    var enVoice: String?
        get() = p.getString("enVoice", null)
        set(v) = p.edit().putString("enVoice", v).apply()

    var expressive: Boolean
        get() = p.getBoolean("expressive", true)
        set(v) = p.edit().putBoolean("expressive", v).apply()

    var listenEnglish: Boolean
        get() = p.getBoolean("listenEnglish", false)
        set(v) = p.edit().putBoolean("listenEnglish", v).apply()

    var wakeEnabled: Boolean
        get() = p.getBoolean("wakeEnabled", false)
        set(v) = p.edit().putBoolean("wakeEnabled", v).apply()

    /** Base URL of the user's OWN https proxy (it holds any API keys, never the app). */
    var proxyBase: String
        get() = p.getString("proxyBase", "") ?: ""
        set(v) = p.edit().putString("proxyBase", v).apply()

    var cloudEnabled: Boolean
        get() = p.getBoolean("cloudEnabled", false)
        set(v) = p.edit().putBoolean("cloudEnabled", v).apply()

    fun toParams() = VoiceParams(
        rate, pitch, volume, hiVoice, enVoice, expressive,
        if (cloudEnabled && proxyBase.startsWith("https://")) proxyBase.trimEnd('/') + "/tts" else null
    )
}
