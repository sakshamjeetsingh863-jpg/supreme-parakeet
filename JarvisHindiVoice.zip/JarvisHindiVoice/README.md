# JARVIS AI — Hindi Voice Edition (Kotlin, Android)

Free offline Hindi/English voice (Android TextToSpeech), futuristic blue UI, animated waveform,
voice input, 7:00 AM IST Hindi wake-up, adjustable speed/pitch/volume, test-before-save.

## Setup (beginner steps)
1. Install Android Studio (Koala or newer). 
2. File > Open > choose the `JarvisHindiVoice` folder. Let Gradle sync (needs internet once).
3. Use a real phone (Android 8.0+; USB debugging on). Emulators often lack Hindi voice/speech services.
4. On the phone: Settings > System > Languages > Text-to-speech > Google Speech Services > install **Hindi (India)** voice data.
5. Press Run. Open the app > Settings > pick a Hindi voice > "Apply cartoon-comedy preset" > "Test voice" > Save.
6. For the 7:00 AM message: enable the switch, tap "Allow exact alarms", allow notifications, and exempt the app from battery optimization.

## Project map
- `VoiceEngine.kt`  offline TTS, sentence-level pitch/speed/pauses, optional cloud playback
- `Persona.kt`      original playful interjections ("अरे वाह!", "हा हा हा!")
- `Brain.kt`        offline replies (time, date, jokes, greetings) + optional proxy chat
- `WaveformView.kt` animated blue waveform
- `AlarmScheduler.kt`, `WakeUpReceiver.kt`, `WakeUpService.kt` 7:00 AM IST wake-up
- `MainActivity.kt`, `SettingsActivity.kt`, `SettingsStore.kt`

## Optional online voice / AI (no keys in the app)
Run your own small https server that holds any API keys. The app only talks to it if you enter its URL:
- `POST {base}/chat`  body `{"message":"..."}`  returns `{"reply":"..."}`
- `POST {base}/tts`   body `{"text":"...","lang":"hi"|"en"}`  returns `audio/mpeg`
Use a TTS provider whose licence allows your use and a voice you are authorised to use (a stock voice,
or your own consented voice). Do not use a clone of a real person/character without permission.

## Limitations
- The sound is a tuned system voice, not any specific person or cartoon character.
- Voice gender and quality depend on the voices installed on the phone; try each one with Test.
- Waveform is state-driven, not real audio amplitude.
- OEM battery managers can block the 7:00 AM service. Exact-alarm permission is required for punctuality.
- Offline replies are simple keyword rules; smarter answers need your own proxy.
